import './style.css'

const API_URL = "http://localhost:3000/todos"

// 1. Obtener todas las tareas del servidor (GET)
async function getTodos() {
  try {
    const response = await fetch(API_URL)
    if (!response.ok) throw new Error('Error al obtener las tareas')
    return await response.json()
  } catch (error) {
    console.error('Error en el GET:', error)
    return []
  }
}

// 2. Guardar una nueva tarea en el servidor (POST)
async function createTodo(title) {
  const newTodo = {
    title: title,
    completed: false // Por defecto inicia sin completar
  }

  try {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newTodo)
    })

    if (!response.ok) throw new Error('Error al guardar la tarea')

    // Si se guarda con éxito, volvemos a pintar la lista
    await renderTodos()
  } catch (error) {
    console.error('Error en el POST:', error)
    alert("No se pudo guardar la tarea.")
  }
}

// 3. Eliminar una tarea de forma permanente (DELETE)
async function deleteTodo(id) {
  try {
    const response = await fetch(`${API_URL}/${id}`, {
      method: 'DELETE'
    })

    if (!response.ok) throw new Error('Error al eliminar la tarea')

    // Refrescamos la lista en la pantalla para que desaparezca
    await renderTodos()
  } catch (error) {
    console.error('Error en el DELETE:', error)
    alert("No se pudo eliminar la tarea.")
  }
}

// 4. Renderizar (pintar) las tareas en el HTML
async function renderTodos() {
  const todoContainer = document.getElementById("todoList")
  if (!todoContainer) return

  const todos = await getTodos()
  todoContainer.innerHTML = "" // Limpiamos para evitar duplicados

  if (todos.length === 0) {
    todoContainer.innerHTML = `
      <p class="text-center text-slate-500 py-4">¡Excelente! No tienes tareas pendientes. 🎉</p>
    `
    return
  }

  todos.forEach(todo => {
    todoContainer.innerHTML += `
      <div class="flex items-center justify-between p-4 bg-slate-800 border border-slate-700/60 rounded-xl shadow-md transition-all hover:border-slate-600 group">
        <span class="text-slate-200 font-medium">${todo.title}</span>
        
        <button 
          data-id="${todo.id}" 
          class="btn-delete bg-red-600/20 hover:bg-red-600 text-red-400 hover:text-white px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all active:scale-95"
        >
          Eliminar
        </button>
      </div>
    `
  })

  // Asignar los eventos de click a cada botón de eliminar creado
  const deleteButtons = document.querySelectorAll(".btn-delete")
  deleteButtons.forEach(button => {
    button.addEventListener("click", (event) => {
      const todoId = event.target.getAttribute("data-id")
      deleteTodo(todoId)
    })
  })
}

// 5. Escuchar el envío del formulario
document.getElementById("todoForm").addEventListener("submit", async (event) => {
  event.preventDefault()
  
  const todoInput = document.getElementById("todoInput")
  const titleText = todoInput.value.trim()

  if (!titleText) {
    alert("¡Por favor escribe una tarea antes de agregar!")
    return
  }

  await createTodo(titleText)
  todoInput.value = "" // Limpiar la casilla de entrada
})

// Cargar las tareas al iniciar la página
document.addEventListener("DOMContentLoaded", renderTodos)
